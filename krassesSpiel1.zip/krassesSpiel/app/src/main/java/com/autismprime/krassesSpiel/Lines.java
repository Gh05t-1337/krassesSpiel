package com.autismprime.krassesSpiel;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
//import android.graphics.Style;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;


public class Lines extends SurfaceView implements View.OnTouchListener/*,View.OnClickListener*/, SensorEventListener {
    Paint pain=new Paint();
    DisplayMetrics mets=new DisplayMetrics();
    Sensor sen;//
    SensorManager man;//
    int hoch;
    int weit;
SurfaceHolder hold;
    MThread mn=new MThread(this);
    ArrayList<float[]> bullets = new ArrayList<>();
    ArrayList<float[]> badBullets = new ArrayList<>();
    ArrayList<int[]> sqrs = new ArrayList<>();
    float movVec=0;
   // float ballX;
   // float ballY;
   // float rotPos=100;
    float blauPos=100;
    int points=0;
    boolean dead=false;
    int deadRadius=0;
    boolean moschän;

    int[] colors;
    String[][] kreisFarben={{"#ff5096","#ffb100"},{"#d88bff","#c2eb00"},{"#ff7d6a","#99f119"},
            {"#ff7d6a","#2ad8af"},{"#d88bff","#00e48d"},{"#54c1f8","#4dd472"},{"#41acff","#ffe900"},
            {"#e9f500","#ff7e4d"}, {"#ff799d","#8a6ad2"}};

            /*{{"#800080","#FFa500"},{"#d8479c","#ffff00"},{"#ff0000","#b4fc00"},
            {"#FFa500","#00ff00"},{"#ffff00","#05fcd7"},{"#b4fc00","#0000ff"},{"#00ff00","#6600FF"},
            {"#05fcd7","#800080"},{"#0000ff","#d8479c"},{"#6600FF","#ff0000"}};*/
    GradientDrawable gd;


    public Lines(Context con,boolean moschn){
        super(con);

        man=(SensorManager)con.getSystemService(Context.SENSOR_SERVICE);//
        sen=man.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);//
        man.registerListener(this,sen,SensorManager.SENSOR_DELAY_NORMAL);//

        hold=getHolder();
        hold.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {

                mn.setRunning(true);
                mn.start();
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                mn.setRunning(false);
            }
        });

        setOnTouchListener(this);
        setSystemUiVisibility(SYSTEM_UI_FLAG_FULLSCREEN|SYSTEM_UI_FLAG_IMMERSIVE_STICKY|SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        init();
       ((Activity) con).getWindowManager().getDefaultDisplay().getMetrics(mets);
       hoch=mets.heightPixels;
       weit=mets.widthPixels;
        //ballX=weit/2;
       // ballY=hoch/2;
        moschän=moschn;
        sqrs.add(new int[]{10, 50, weit/8, hoch/8});
        sqrs.add(new int[]{400, 90, weit/4, hoch/16});
        sqrs.add(new int[]{500, 40, weit/6, hoch/16});


        //color gradient
        colors = new int[]{Color.parseColor(kreisFarben[0][0]), Color.parseColor(kreisFarben[0][1])};
        //create a new gradient color
        gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, colors);
        gd.setCornerRadius(0f);
        this.setBackground(gd);
    }
    void init(){
        pain.setColor(Color.BLACK);
    }
    @Override
    public void onDraw(Canvas can){
        //alt pain.setColor(Color.BLACK);
        //alt can.drawLine(0,hoch/2,weit,hoch/2,pain);
        //alt pain.setColor(Color.RED);
        //alt can.drawRect(rotPos,hoch/400,rotPos+weit/5,hoch/400+20,pain);
        //alt pain.setColor(Color.BLUE);
        //alt can.drawRect(blauPos,(hoch-(hoch/400))-20,weit/5+blauPos,hoch-(hoch/400),pain);
      //  can.drawText(hoch+","+weit,200,600,pain);
        //alt pain.setColor(0xFF00574B);
        //alt can.drawCircle(ballX,ballY,8,pain);

        ////NEU
        //Bullets
        //pain.setColor(Color.rgb(255, 255, 0));
        pain.setColor(Color.rgb(255, 255, 255));
        int i=0;
        while(i< bullets.size()){
            //Log.i("", String.valueOf(i));
            bullets.set(i, new float[]{bullets.get(i)[0], (bullets.get(i)[1] + movVec)});
            can.drawCircle(bullets.get(i)[0],bullets.get(i)[1],8,pain);

            //check if enemie is hit
            int s=0;
            Random r = new Random();
            while(s<sqrs.size()) {
                if (bullets.get(i)[1]<sqrs.get(s)[1]+sqrs.get(s)[3] && //bullets.get(i)[1]>sqrs.get(s)[1] &&
                        bullets.get(i)[0]>sqrs.get(s)[0]&&bullets.get(i)[0]<sqrs.get(s)[0]+sqrs.get(s)[2]){
                    points++;
                    if(points%100==0) {
                        colors = new int[]{Color.parseColor(kreisFarben[(points/10)% kreisFarben.length][0]), Color.parseColor(kreisFarben[(points/10)% kreisFarben.length][1])};
                        //create a new gradient color
                        gd = new GradientDrawable(
                                GradientDrawable.Orientation.TOP_BOTTOM, colors);
                        gd.setCornerRadius(0f);
                        this.setBackground(gd);
                    }

                    sqrs.remove(s);
                    sqrs.add(new int[]{r.nextInt((weit-weit/3)  + 1), r.nextInt((hoch/3*2-hoch/3)  + 1),r.nextInt(((weit/3-weit/8)  + 1)) + weit/8 ,r.nextInt(((hoch/4-hoch/10)  + 1)) + hoch/10});
                }
                s++;
            }

            if(bullets.get(i)[1]<0){
                bullets.remove(i);
                continue;
            }
            i++;
        }

        //Enemies
        i=0;
        //pain.setColor(Color.rgb(190, 40, 0));
        pain.setColor(Color.rgb(0, 0, 0));
        while(i< sqrs.size()){
            can.drawRect(sqrs.get(i)[0],sqrs.get(i)[1],sqrs.get(i)[0]+sqrs.get(i)[2],sqrs.get(i)[1]+sqrs.get(i)[3],pain);
            i++;
        }

        //BadBullets
        //pain.setColor(Color.rgb(255, 155, 30));
        pain.setColor(Color.rgb(0, 0, 0));
        i=0;
        while(i< badBullets.size()){
            //Log.i("", String.valueOf(i));
            badBullets.set(i, new float[]{badBullets.get(i)[0], (badBullets.get(i)[1] - movVec/2)});
            can.drawCircle(badBullets.get(i)[0],badBullets.get(i)[1],8,pain);

            //check if player is hit
                if (badBullets.get(i)[1]<(hoch-(hoch/400))-20 && badBullets.get(i)[1]>(hoch-(hoch/400))-20-80&&
                        badBullets.get(i)[0]<blauPos+110&&badBullets.get(i)[0]>blauPos+10){
                    dead=true;
                    mn.st=0;
                    badBullets.remove(i);
                    continue;

                }


           // Log.i("",badBullets.toString()+String.valueOf(i));
            if(badBullets.get(i)[1]>hoch){

                badBullets.remove(i);
                continue;
            }
            i++;
        }


        //Spaceship
        if(!dead) {
            //pain.setColor(Color.rgb(70, 160, 255));
            pain.setColor(Color.rgb(255, 255, 255));
            pain.setStyle(Paint.Style.FILL);
            Path wallpath = new Path();
            wallpath.reset(); // only needed when reusing this path for a new build
            wallpath.moveTo(blauPos, (hoch - (hoch / 400)) - 20); // used for first point
            wallpath.lineTo(blauPos + 60, (hoch - (hoch / 400)) - 20 - 100);
            wallpath.lineTo(blauPos + 120, (hoch - (hoch / 400)) - 20);
            //wallpath.lineTo(x[3], y[3]);
            // wallpath.lineTo(x[0], y[0]); // there is a setLastPoint action but i found it not to work as expected
            can.drawPath(wallpath, pain);
        }
        else{
            pain.setColor(Color.rgb(255, 255, 255));
            if(deadRadius<70){
                can.drawCircle(blauPos+60,(hoch - (hoch / 400)) - 20-50,deadRadius,pain);
            }
            deadRadius+=2;
        }

        //Points
        pain.setColor(Color.rgb(255, 255, 255));
       // pain.setColor(Color.rgb(255, 255, 100));
        pain.setTextSize(32);
        can.drawText(String.valueOf(points), 2, 34, pain);
        //DebugLastValue>
        //pain.setColor(Color.rgb(255, 0, 0));
        //pain.setTextSize(32);
       // can.drawText(String.valueOf(lastValue), weit-128-32, 34, pain);
        //<
        if(deadRadius>=200){
            //pain.setColor(Color.rgb(119, 221, 119));
            pain.setColor(Color.rgb(255, 255, 255));
            pain.setTextSize(points);
            can.drawText(String.valueOf(points), weit/2-points/2*String.valueOf(points).length()/2, hoch/2-points/2, pain);
        }
        ////!NEU
    }
    float lastPointerPos=0;
    @Override
    public boolean onTouch(View v,MotionEvent e){

        if(!dead &&!moschän) {
            if (e.getAction() == MotionEvent.ACTION_DOWN){
                if(mn.st>0&&e.getX()>=weit/2){
                    blauPos+=80;
                }
                if(mn.st<0&&e.getX()<weit/2){
                    blauPos-=80;
                }
                mn.st = (e.getX() >= weit / 2) ? 6 : -6;
            }
            else if(e.getAction()==MotionEvent.ACTION_MOVE){
                if(e.getX() > lastPointerPos+10f) mn.st = 6;
                if(e.getX() < lastPointerPos-10f) mn.st = -6;
                //Log.i("", String.valueOf(lastPointerPos));
            }
            lastPointerPos=e.getX();
            //blauPos=e.getX()-weit/10;
            //rotPos=e.getX()-weit/10;
            v.postInvalidate();//invalidate();
        }
        else if(!dead&&moschän){
            if (e.getAction() == MotionEvent.ACTION_DOWN){
                if(e.getX()>=weit/2){
                    blauPos+=80;
                }
                if(e.getX()<weit/2){
                    blauPos-=80;
                }
               // mn.st = (e.getX() >= weit / 2) ? 6 : -6;
            }
        }
        if(deadRadius>=200){
            mn=new MThread(this);
            bullets = new ArrayList<>();
            badBullets = new ArrayList<>();
            sqrs = new ArrayList<>();
            movVec=0;
            //ballX;
            //ballY;
            //rotPos=100;
            colors = new int[]{Color.parseColor(kreisFarben[0][0]), Color.parseColor(kreisFarben[0][1])};
            //create a new gradient color
            gd = new GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM, colors);
            gd.setCornerRadius(0f);
            this.setBackground(gd);

            lastValue=0;
            blauPos=100;
            points=0;
            dead=false;
            deadRadius=0;
            sqrs.add(new int[]{10, 50, weit/8, hoch/8});
            sqrs.add(new int[]{400, 90, weit/4, hoch/16});
            sqrs.add(new int[]{500, 40, weit/6, hoch/16});
            mn=new MThread(this);
            mn.setRunning(true);
            mn.start();
        }
       // System.exit(0);
        return true;
    }
    float lastValue=0;
    @Override
    public void onSensorChanged(SensorEvent e){
        if(!dead&&moschän) {
           // if (Math.abs(e.values[0]) > Math.abs(e.values[1])) { alt
                // if(Math.abs(e.values[0])<0.3f){ alt
                //    mn.st=0; alt
                // } alt
                /*  else{   mn.st=(e.values[0]-(e.values[0]/Math.abs(e.values[0])*0.3f))*2;*///} alt
                if(e.values[0]<6&&e.values[0]>-6)mn.st=-e.values[0]*3f;
                else if(e.values[0]>=6)mn.st=-6;
                else mn.st=6;
                //if(e.values[0]>lastValue+1f) mn.st =-6;
                //if(e.values[0]<lastValue-1f) mn.st = 6;
                //if(e.values[0]>-0.4f&&e.values[0]<0.4f) mn.st=0; alt
                //mn.st = (e.values[0] >= lastValue) ? -6 : 6; alt

           // } alt
            postInvalidate();
            lastValue=e.values[0];
        }
        //neu Log.i("", String.valueOf(e.values[0]));

    }
    @Override
    public void onAccuracyChanged(Sensor sensor,int accuracy){

    }
/*
    @Override
    public void onClick(View view) {
        /*if(!dead){
            if(mn.st>0 && getPosition() >= weit / 2)
                blauPos+=80;
        }*/
    /*}*/
}

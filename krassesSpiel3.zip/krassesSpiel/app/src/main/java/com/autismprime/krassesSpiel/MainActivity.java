package com.autismprime.krassesSpiel;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;

import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;
import android.util.DisplayMetrics;
import android.widget.Button;

public class MainActivity extends Activity /*implements View.OnTouchListener */{
Lines lins;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       /* int[] colors = {Color.parseColor("#800080"),Color.parseColor("#FF7600")};

        //create a new gradient color
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, colors);

        gd.setCornerRadius(5f);*/
        //apply the button background to newly created drawable gradient
        //view.setBackground(gd);

        lins=new Lines(this,false);
        //lins.setBackgroundColor(Color.rgb(0, 0, 27));
        //lins.setBackground(gd);

        Button button = (Button) findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                lins.moschän=true;
                setContentView(lins);
            }
        });

        Button button2 = (Button) findViewById(R.id.button3);
        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                lins.moschän=false;
                //lins.setBackgroundColor(Color.rgb(0, 0, 27));
                setContentView(lins);
            }
        });

       // lins=new Lines(this,true);
       // lins.setBackgroundColor(Color.rgb(0, 0, 27));
       // setContentView(lins);
        //SurfaceView sr=new SurfaceView(this);
        //Canvas c=new Canvas();
        //Rect r=new Rect();
        //c.drawRect(r,null);
        //sr.draw(c);
    }

   /* @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        int hoch=new DisplayMetrics().heightPixels;
        if (motionEvent.getY()<hoch/2)
            lins=new Lines(this,true);
        else
            lins=new Lines(this,false);
        lins.setBackgroundColor(Color.rgb(0, 0, 27));
        setContentView(null);
        setContentView(lins);
        return false;
    }*/
}
